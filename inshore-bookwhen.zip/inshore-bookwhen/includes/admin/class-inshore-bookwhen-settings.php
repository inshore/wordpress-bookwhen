<?php
/**
 * RP_Analytics_Settings
 *
 * @package RP_Analytics_Settings
 * @since 1.0.1
 */

defined('ABSPATH') || exit;

class InShore_Bookwhen_Settings
{
    public function __construct()
    {
        error_log(__FUNCTION__);
        add_action( 'admin_init', 'inshore_bookwhen_settings_init' );
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
    }

    /**
     * Registers a new settings page under Settings.
     */
    public function admin_menu() {
        add_options_page(
            __( 'Page Title', 'textdomain' ),
            __( 'Circle Tree Login', 'textdomain' ),
            'manage_options',
            'options_page_slug',
            array(
                $this,
                'settings_page'
            )
            );
    }
    
    public function inshore_bookwhen_settings_init() {
        // Register a new setting for "wporg" page.
        register_setting( 'bookwhen', 'bookwhen_options' );
        
        // Register a new section in the "wporg" page.
        add_settings_section(
            'wporg_section_developers',
            __( 'The Matrix has you.', 'bookwhen' ), 'wporg_section_developers_callback',
            'wporg'
            );
        
        // Register a new field in the "wporg_section_developers" section, inside the "wporg" page.
        add_settings_field(
            'wporg_field_pill', // As of WP 4.6 this value is used only internally.
            // Use $args' label_for to populate the id inside the callback.
            __( 'Pill', 'bookwhen' ),
            'wporg_field_pill_cb',
            'wporg',
            'wporg_section_developers',
            array(
                'label_for'         => 'wporg_field_pill',
                'class'             => 'wporg_row',
                'wporg_custom_data' => 'custom',
            )
            );
    }
}

new InShore_Bookwhen_Settings();
